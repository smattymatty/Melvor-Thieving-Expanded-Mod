export function init(ctx) {
  //ctx.settings.section("General").add({
  //  type: "dropdown",
  //  color: "info",
  //  name: "sort-thieving-areas",
  //  label: "Awesomeness Detection",
  //  hint: "Determines if you are awesome or not.",
  //  options: [],
  //  default: "normal",
  //});
}
